<template>


<body class="bg-slate-800 text-heading min-h-screen">
    <nav class="bg-gradient-to-r from-blue-900 via-purple-600 to-fuchsia-700 border-b border-divider shadow-sm sticky top-0 z-10">
          <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
                <div class="text-2xl font-extrabold tracking-tight">
                    
                    <span class="text-brand">Smart</span><span class="text-accent text-pink-400">Event</span>
                    
                </div>
                <div class="flex gap-2 text-sm font-medium">
                    <span>Eventos</span>
                    <span>Inscripción</span>
                    
                    <button class="px-4 py-2 text-sm text-white rounded-full bg-gradient-to-r from-blue-800 to-fuchsia-800 hover:bg-none hover:bg-white hover:text-fuchsia-600 shadow-fuchsia-950 shadow-2xl transition-all">
                        Iniciar Sesión

                    </button>

                    

                  


                </div>
            </div>
    </nav>

    <main>
        <slot/>
    </main>
    
</body>


</template>
