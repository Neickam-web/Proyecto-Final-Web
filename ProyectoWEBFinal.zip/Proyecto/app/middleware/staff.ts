export default defineNuxtRouteMiddleware(() => {
  const { user } = useUserSession();

  if (user.value?.rol !== "Staff") {
    throw createError({ statusCode: 403, message: "Acceso Denegado" });
  }
});
