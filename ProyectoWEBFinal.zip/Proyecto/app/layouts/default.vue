<script setup lang="ts">
import type { Usuario } from '~/types/usuario'

const route = useRoute()
const NavigationLinks = [
    { label: "Eventos", to: "/" },
    { label: "Inscripciones", to:"/inscripciones"}

]

const NavigationLinks1 = [
    { label: "Eventos", to: "/" },
    { label: "Inscripciones", to: "/inscripciones" },
    { label: "Panel", to:"/admin"}

]
const {loggedIn, user, clear} = useUserSession()
const cerrarSesion = async () => {
    await clear()
    await navigateTo('/login')
}
</script>
<template>


    <body class=" bg-slate-950 text-heading min-h-screen">
        <nav
            class="bg-gradient-to-r from-blue-900 via-purple-600 to-fuchsia-700 border-b border-divider shadow-sm sticky top-0 z-50">
            <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
                <div class="text-2xl font-extrabold tracking-tight">

                    <span class="text-brand">Smart</span><span class="text-accent text-pink-400">Event</span>

                </div>
                <div class="flex gap-6 text-sm font-medium">
                    <div v-if = "!loggedIn">
                         <NuxtLink v-for="links in NavigationLinks" key="link.to" :to="links.to"
                         class="text-sm  text-white  hover:bg-none hover:bg-white px-4 py-1 rounded-full shadow-fuchsia-950 shadow-2xl transition-all hover:text-fuchsia-950">
                         {{ links.label }}
                         </NuxtLink>
                    </div>
                    <div v-else>
                         <NuxtLink v-for="links1 in NavigationLinks1" key="link1.to" :to="links1.to"
                         class="text-sm text-white  hover:bg-none hover:bg-white px-4 py-1 rounded-full shadow-fuchsia-950 shadow-2xl transition-all hover:text-fuchsia-950">
                         {{ links1.label }}
                         </NuxtLink>

                    </div>
                </div>
                <div v-if="loggedIn" >
                    <span class="text-sm font-medium text-slate-300 px-4" >
                        <strong class="text-brand-blue">{{ user?.nombre }} {{ user?.apellido }}  </strong>
                    </span>
                    <UButton
                        @click="cerrarSesion"
                        class="px-4 py-2 text-sm text-white rounded-full bg-gradient-to-r from-blue-800 to-fuchsia-800 hover:bg-none hover:bg-white hover:text-fuchsia-600 shadow-fuchsia-950 shadow-2xl transition-all" to="/login">
                        Cerrar Sesión

                    </UButton>
                </div>
                <div v-else>
                    <UButton
                        class="px-4 py-2 text-sm text-white rounded-full bg-gradient-to-r from-blue-800 to-fuchsia-800 hover:bg-none hover:bg-white hover:text-fuchsia-600 shadow-fuchsia-950 shadow-2xl transition-all" to="/login">
                        Iniciar Sesión
                    </UButton>

                </div>
            </div>
        </nav>

        <main  class="">
            <slot />
        </main>

    </body>A

</template>
