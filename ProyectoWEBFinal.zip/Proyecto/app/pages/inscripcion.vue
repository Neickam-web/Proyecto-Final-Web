<script setup lang="ts">
import { ref } from 'vue'

const eventoSeleccionado = useState<any>('eventoActual')

const formulario = ref({
  nombre: '',
  apellido: '',
  email: ''
})

const inscrito = ref(false)

const inscribir = async () => {
  try {
    await $fetch('/api/inscripcion/crear', {
      method: 'POST',
      body: {
        nombre: formulario.value.nombre,
        apellido: formulario.value.apellido,
        email: formulario.value.email,
        eventoId: eventoSeleccionado.value.id 
      }
    })
    
    inscrito.value = true
    
    setTimeout(() => {
      formulario.value.nombre = ''
      formulario.value.apellido = ''
      formulario.value.email = ''
      inscrito.value = false
    }, 2000)
    
  } catch (error) {
    console.error("Hubo un error al inscribir:", error)
  }
}
</script>
<template>
  <main class="min-h-screen bg-slate-950 py-12 px-4 flex flex-col items-center justify-center">
    
    <div class="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-xl p-8 shadow-lg">
      <h1 class="text-2xl font-bold text-white mb-6">Formulario de Inscripción</h1>
      
      <div v-if="eventoSeleccionado" class="mb-6 bg-slate-800 p-4 rounded-lg border border-slate-700">
        <p class="text-sm text-slate-400">Evento seleccionado:</p>
        <p class="text-lg font-bold text-purple-400">{{ eventoSeleccionado.titulo }}</p>
      </div>
      <div v-else class="mb-6 bg-slate-800 p-4 rounded-lg border border-slate-700">
        <p class="text-sm text-slate-400">No has seleccionado ningún evento. Vuelve al inicio y elige uno.</p>
      </div>

      <form @submit.prevent="inscribir" class="space-y-5">
        <div class="flex flex-col sm:flex-row gap-5">
          <div class="flex-1">
            <label class="block text-sm font-semibold text-slate-400 mb-2">Nombre</label>
            <input 
              v-model="formulario.nombre" type="text" required Dplaceholder="Ej: Juan"
              class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500"
            >
          </div>

          <div class="flex-1">
            <label class="block text-sm font-semibold text-slate-400 mb-2">Apellido</label>
            <input 
              v-model="formulario.apellido" type="text" required placeholder="Ej: Pérez"
              class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500"
            >
          </div>
        </div>

        <div>
          <label class="block text-sm font-semibold text-slate-400 mb-2">Correo Electrónico</label>
          <input 
            v-model="formulario.email" type="email" required placeholder="juan@correo.com"
            class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500"
          >
        </div>

        <div v-if="inscrito" class="text-green-400 bg-green-500/10 border border-green-500/20 px-4 py-3 rounded-lg text-sm text-center">
          ¡Te has inscrito exitosamente!
        </div>

        <button 
          type="submit" :disabled="!eventoSeleccionado"
          class="w-full mt-2 bg-purple-600 hover:bg-purple-500 disabled:bg-slate-700 disabled:text-slate-500 text-white font-bold py-3 px-4 rounded-lg transition-all"
        >
          Confirmar Inscripción
        </button>
      </form>
    </div>
  </main>
</template>

