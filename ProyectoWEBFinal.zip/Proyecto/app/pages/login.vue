<script setup lang="ts">
import { z } from 'zod'

const schemaLogin = z.object({
    email: z.email({ message: 'Debe ingresar un correo válido.' }),
    password: z.string().min(6, 'La contraseña debe tener como mínimo 6 caracteres.')
})

const iniciandoSesion = ref(false)
const errorForm = ref('')
const formLogin = reactive({
    email: '',
    password: ''
})

const { fetch: fetchSession } = useUserSession()

async function login() {
    iniciandoSesion.value = true
    errorForm.value = ''

    try {
        await $fetch('/api/auth/login', {
            method: 'POST',
            body: {
                email: formLogin.email,
                password: formLogin.password
            }
        })
        await fetchSession()
        await navigateTo('/')
    }
    catch (err: any) {
        errorForm.value = getApiErrorMessage(err, 'No se pudo iniciar sesión')
    }
    finally {
        iniciandoSesion.value = false
    }
}
</script>

<template>
    <div class="flex min-h-screen items-center justify-center px-4 py-10 sm:px-6 lg:px-8">
        <UCard class="w-full max-w-md border bg-gradient-to-r from-slate-900 via-purple-950 to-purple-800 border-brand-border shadow-xl shadow-brand-blue/5">
            <template #header>
                <div class="space-y-3 text-center">
                    <p class="text-sm font-semibold uppercase tracking-[0.24em] text-brand-cyan">
                        Smart Event
                    </p>
                    <p class="text-2xl font-bold text-brand-blue">
                        Iniciar sesión
                    </p>
                    <p class="text-sm text-brand-gray/70">
                        Ingrese sus credenciales
                    </p>
                </div>
            </template>

            <div>
                <UForm class="space-y-5" :state="formLogin" :schema="schemaLogin" @submit="login">
                    <UFormField label="Correo" name="email">
                        <UInput v-model="formLogin.email" placeholder="tu@correo.com" size="xl" class="w-full" />
                    </UFormField>

                    <UFormField label="Contraseña" name="password">
                        <UInput v-model="formLogin.password" placeholder="Ingresa tu contraseña" type="password"
                            size="xl" class="w-full" />
                    </UFormField>

                    <!-- si el frmurlario tira error -->
                    <UAlert v-if="errorForm" color="error" variant="soft" icon="i-heroicons-exclamation-circle"
                        :title="errorForm" />

                    <UButton type="submit" :loading="iniciandoSesion" block size="xl"
                        class="bg-brand-blue text-white hover:bg-brand-blue/90">
                        Ingresar al Sistema
                    </UButton>
                </UForm>
            </div>
        </UCard>
    </div>
</template>