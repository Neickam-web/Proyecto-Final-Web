
<script setup lang="ts">
import { ref } from 'vue'

const email = ref('')
const yaBusco = ref(false)
const eventos = ref<any[]>([])

const buscarMisEventos = async() => {
    yaBusco.value = true
    try {


        const data = await $fetch('/api/inscripcion/buscar', {
            method: 'GET',
            query: { email: email.value }
        })
        eventos.value = data as any[]

    } catch (error) {
        console.error("Error al buscar: ", error)
        eventos.value = []
    }

    
  
}
</script>
<template>
  <main class="min-h-screen bg-slate-950 py-12 px-4 flex flex-col items-center">
    
  
    <div class="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-xl p-8 shadow-lg mb-8">
      <h1 class="text-2xl font-bold text-white mb-2">Mis Inscripciones</h1>
      <p class="text-slate-400 text-sm mb-6">Ingresa el correo con el que te registraste para ver tus eventos.</p>
      
      <form @submit.prevent="buscarMisEventos" class="flex flex-col sm:flex-row gap-4">
        <input 
          v-model="email" type="email" required placeholder="tu@correo.com"
          class="flex-1 w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500"
        >
        <button type="submit" class="bg-purple-600 hover:bg-purple-500 text-white font-bold py-3 px-6 rounded-lg transition-all">
          Buscar
        </button>
      </form>
    </div>

    <div v-if="yaBusco" class="w-full max-w-2xl">
        <h2 class="text-xl font-bold text-white mb-4">Tus Eventos</h2>
        
        <!-- si es q encuentra eventos en la lista -->
        <div v-if="eventos.length > 0" class="space-y-4">
            <div v-for="evento in eventos" :key="evento.id" class="bg-slate-900 border border-slate-800 p-5 rounded-lg">
                <h3 class="text-lg font-bold text-white mb-1">{{ evento.titulo }}</h3>
                <p class="text-sm text-slate-400">
                  <strong class="text-purple-400">Fecha:</strong> {{ new Date(evento.fecha).toLocaleDateString('es-CL') }}
                </p>
                <p class="text-sm text-slate-400">
                  <strong class="text-purple-400">Lugar:</strong> {{ evento.lugar }}
                </p>
            </div>
        </div>

        <div v-else class="bg-slate-900 border border-slate-800 p-6 rounded-lg text-center text-slate-400">
            No encontramos inscripciones con ese correo. Revisa si está bien escrito.
        </div>
    </div>

  </main>
</template>
