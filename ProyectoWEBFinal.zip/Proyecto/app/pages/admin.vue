<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'

definePageMeta({ middleware: 'staff' })
const { user, clear } = useUserSession()

const salir = async () => {
  await clear()
  await navigateTo('/login')
}

const formEvento = reactive({ 
  titulo: '', 
  fecha: '', 
  lugar: '', 
  valor: 0,
  imagen: '' 
})

const guardandoEvento = ref(false)
const mensaje = ref('')

const eventos = ref<any[]>([])


const cargarEventos = async () => {
  try {
  
    eventos.value = await $fetch<any[]>('/api/eventos/evento') 
  } catch (error) {
    console.error("Error al cargar eventos:", error)
  }
}

async function guardarEvento() {
  guardandoEvento.value = true
  try {
    await $fetch('/api/eventos/evento', {
      method: 'POST',
      body: {
        titulo: formEvento.titulo,
        fecha: formEvento.fecha,
        lugar: formEvento.lugar,
        valor: formEvento.valor,
        imagen: formEvento.imagen 
      }
    })
    
    formEvento.titulo = ''
    formEvento.fecha = ''
    formEvento.lugar = ''
    formEvento.valor = 0
    formEvento.imagen = ''
    
    mensaje.value = '¡Evento guardado correctamente en la base de datos!'
    setTimeout(() => { mensaje.value = '' }, 1000)

    await cargarEventos()

  } catch (error) {
    console.error("Error al guardar:", error)
  } finally {
    guardandoEvento.value = false
  }
}


const borrarEvento = async (id: number) => {
  if (!confirm('¿Estás seguro de que quieres borrar este evento?')) return

  try {
 
    await $fetch('/api/eventos/eventos', {
      method: 'DELETE',
      body: { id }
    })
    
    
    await cargarEventos()
  } catch (error) {
    console.error("Error al borrar el evento:", error)
  }
}

const alSeleccionarImagen = (event: any) => {
  if (event.target.files.length > 0) {
    formEvento.imagen = event.target.files[0].name
  } else {
    formEvento.imagen = '' 
  }
}


const formatearFecha = (fechaString: string) => {
  if (!fechaString) return ''
  return new Date(fechaString).toLocaleDateString('es-CL', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
}


onMounted(() => {
  cargarEventos()
})
</script>

<template>
  <main class="min-h-screen bg-slate-950 py-8 px-4">
    
    <div class="max-w-5xl mx-auto space-y-8">
      
      
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg flex justify-between items-center">
        <div>
          <h1 class="text-2xl font-bold text-white">Panel de Administración</h1>
          <p class="text-slate-400 text-sm mt-1">
             <strong class="text-purple-400">{{ user?.nombre }} {{ user?.apellido }}</strong>
          </p>
        </div>
        <button @click="salir" class="text-red-400 hover:text-red-300 font-bold transition-colors">
          Cerrar Sesión
        </button>
      </div>
       
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
       
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg h-fit">
          <h2 class="text-lg font-bold text-white mb-4">Agregar Nuevo Evento</h2>
          
          <form @submit.prevent="guardarEvento" class="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label class="block text-xs font-semibold text-slate-400 mb-1">Título</label>
              <input v-model="formEvento.titulo" type="text" required class="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-purple-500">
            </div>
            
            <div>
              <label class="block text-xs font-semibold text-slate-400 mb-1">Fecha y Hora</label>
              <input v-model="formEvento.fecha" type="datetime-local" required class="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-purple-500">
            </div>
            
            <div>
              <label class="block text-xs font-semibold text-slate-400 mb-1">Lugar</label>
              <input v-model="formEvento.lugar" type="text" required class="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-purple-500">
            </div>
            
            <div>
              <label class="block text-xs font-semibold text-slate-400 mb-1">Valor ($)</label>
              <input v-model="formEvento.valor" type="number" required class="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white outline-none focus:border-purple-500">
            </div> 

            <div class="md:col-span-2">
              <label class="block text-xs font-semibold text-slate-400 mb-2">Imagen del evento</label>
             
              <UFileUpload
                accept="image/*"
                icon="i-heroicons-cloud-arrow-up"
                placeholder="Arrastra una imagen aquí o haz clic para buscar"
                size="md"
                class="w-full"
                @change="alSeleccionarImagen"
              />
            </div>

            <div v-if="mensaje" class="md:col-span-2 text-green-400 bg-green-500/10 border border-green-500/20 px-4 py-3 rounded-lg text-sm text-center">
              {{ mensaje }}
            </div>
            
            <button type="submit" :disabled="guardandoEvento" class="md:col-span-2 mt-2 bg-purple-600 hover:bg-purple-500 text-white font-bold py-3 px-4 rounded-lg transition-colors disabled:opacity-50">
              {{ guardandoEvento ? 'Guardando...' : 'Guardar Evento' }}
            </button>
          </form>
        </div>

        
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-lg">
          <h2 class="text-lg font-bold text-white mb-4">Eventos Registrados</h2>
          
          <div class="space-y-3 max-h-full overflow-y-auto pr-2">
            <div v-for="evento in eventos" :key="evento.id" class="bg-slate-800 p-4 rounded-lg flex justify-between items-center border border-slate-700/50">
              <div>
                <p class="font-bold text-slate-200">{{ evento.titulo }}</p>
                <p class="text-xs text-slate-400 flex gap-2">
                  <span> {{ formatearFecha(evento.fecha) }}</span>
                  <span> {{ evento.lugar }}</span>
                </p>
                <p class="text-xs text-purple-400 mt-1 font-semibold">Valor: ${{ evento.valor }}</p>
              </div>
              
              <button @click="borrarEvento(evento.id)" class="bg-red-500/10 text-red-400 hover:bg-red-500/20 hover:text-red-300 text-sm font-semibold transition-colors px-3 py-2 rounded border border-red-500/30">
                Borrar
              </button>
            </div>

            <div v-if="eventos.length === 0" class="text-center text-slate-500 py-8 text-sm">
              Aún no hay eventos registrados.
            </div>
          </div>
        </div>

      </div>
    </div>
  </main>
</template>