<script setup lang="ts">

import type { Evento } from '~/types/evento'
const { data: eventos, pending, error, refresh } = await useFetch<Evento[]>('/api/eventos/evento')

</script>
<template>
    <main class="min-h-screen p-6 md:p-12">
        <div class="max-w-6xl mx-auto ">

            <h1 class="text-3xl text-center font-semibold uppercase tracking-[0.14em] text-brand-cyan md:text-4xl font-bold text-white mb-8 border-b border-purple-500/50 pb-4">
                PRÓXIMOS EVENTOS
            </h1>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <EventoCard v-for="evento in eventos" :evento="evento" />
            </div>

        </div>
    </main>
</template>
