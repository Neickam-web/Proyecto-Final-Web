<script setup lang="ts">
import type { Evento } from '~/types/evento'
const props = defineProps<{ evento: Evento }>()
const eventoSeleccionado = useState<any>('eventoActual', () => null)

const irAInscripcion = () => {
    eventoSeleccionado.value = props.evento
    navigateTo('/inscripcion')
}
</script>

<template>
    <div class="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden shadow-lg p-4">
        <img :src="'/'+evento.imagen" :alt="evento.imagen"
            class="w-full h-48 object-cover rounded-md mb-4 border border-slate-800">

        <div class="space-y-2">
            <h2 class="text-xl font-bold text-white">{{ evento.titulo }}</h2>

            <p class="text-slate-300 text-sm">
                <strong class="text-purple-400">Fecha:</strong> {{ new Date(evento.fecha).toLocaleDateString('es-CL') }}
            </p>

            <p class="text-slate-300 text-sm">
                <strong class="text-purple-400">Lugar:</strong> {{ evento.lugar }}
            </p>

            <p class="text-slate-300 text-sm">
                <strong class="text-purple-400">Valor:</strong>
                <span v-if="evento.valor === 0"> ¡Gratis!</span>
                <span v-else> ${{ evento.valor }}</span>
            </p>

            <!-- Botón de acción simple -->
            <button @click="irAInscripcion"
                class="w-full block text-center mt-6 bg-purple-600 hover:bg-purple-500 text-white font-bold py-2 px-4 rounded-full transition-all">
                Inscribirse
            </button>
        </div>
    </div>
</template>
