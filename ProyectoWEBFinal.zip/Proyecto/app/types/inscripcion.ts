export interface Inscripcion {
    id: number;
  email: string;
  nombre: string;
  apellido: string;
  eventoId: number;
}