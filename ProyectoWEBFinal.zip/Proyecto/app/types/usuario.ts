export interface Usuario{
    email: string
    contraseña: string
    nombre: string
    apellido: string
    rol: string
}