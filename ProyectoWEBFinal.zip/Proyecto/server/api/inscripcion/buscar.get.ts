export default defineEventHandler(async (event) => {
    const query = await getQuery(event)
    const emailBuscado = String(query.email).trim()

    try {
        const registros = await prisma.inscrito.findMany({
        where: { email: emailBuscado },
        include: {
            evento: true
        }

    })

    return registros.map((reg: any) => ({
        id: reg.id,
        titulo: reg.evento.titulo,
        fecha: reg.evento.fecha,
        lugar: reg.evento.lugar
    }))
   





    } catch (error) {
        console.error("Error gigante en Prisma al buscar:", error)
        throw createError({ statusCode: 500, statusMessage: "Error en el servidor" })
    }
    
})