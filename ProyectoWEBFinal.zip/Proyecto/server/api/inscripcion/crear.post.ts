export default defineEventHandler(async (event) => {
    const body = await readBody(event)

    const nuevaInscripcion = await prisma.inscrito.create({
        data: {
            nombre: body.nombre,
            apellido: body.apellido,
            email: body.email,
            eventoId: Number(body.eventoId)
        }

    })

    return {ok: true, inscripcion: nuevaInscripcion}
    
})