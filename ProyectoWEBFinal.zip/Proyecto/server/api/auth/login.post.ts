import bcrypt from "bcryptjs";

export default defineEventHandler(async (event) => {

  const { email, password } = await readBody(event);

  
  if (!email || !password) {
    throw createError({ statusCode: 401, message: "Credenciales no válidas" });
  }

  //revisamos q haya alguna cuenta asociada
  const usuario = await prisma.usuario.findUnique({
    where: { email: String(email) },
  });
  
  if (!usuario) {
    throw createError({ statusCode: 401, message: "Usuario no encontrado" });
  }

  // verificar la contraseña
  const passwordValido = await bcrypt.compare(String(password), usuario.password);
  
  if (!passwordValido) {
    throw createError({ statusCode: 401, message: "Contraseña incorrecta" });
  }

 
  await setUserSession(event, {
    user: {
      email: usuario.email,
      nombre: usuario.nombre,      
      apellido: usuario.apellido,  
      rol: usuario.rol,
    },
  });

  return { ok: true };
});