import bcrypt from "bcryptjs";

export default defineEventHandler(async (event) => {
  // 1. Extraer los datos (añadimos apellido si tu esquema lo pide)
  const { email, password, nombre, apellido, rol } = await readBody(event);

  // 2. Crear el hash del password
  const hash = await bcrypt.hash(password, 12);

  // 3. Insertar el usuario en la BD con todos sus campos
  const usuario = await prisma.usuario.create({
    data: {
      email,
      password: hash,
      nombre,
      apellido: apellido || "", // Evita que explote si apellido es obligatorio
      rol,
    },
  });

  return {
    ok: true,
    usuario,
  };
});
