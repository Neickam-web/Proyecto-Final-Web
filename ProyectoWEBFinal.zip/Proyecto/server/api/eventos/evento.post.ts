export default defineEventHandler(async (event) => {
    const body = await readBody(event)
    const { titulo, fecha, lugar, valor, imagen } = body
    
    const tituloNormalizado = typeof titulo === 'string' ? titulo.trim() : ''
    const lugarnormalizado = typeof lugar === 'string' ? lugar.trim() : ''
    const fechaHora = new Date(fecha)

    const imagenFinal = typeof imagen === 'string' && imagen.trim() !== '' ? imagen.trim() : 'default.jpg'
    
    try {
        const evento = await prisma.evento.create({
            data: {
                titulo: tituloNormalizado,
                fecha: fechaHora,
                lugar: lugarnormalizado,
                imagen: imagenFinal,
                valor: Number(valor)
            }
    
        })

        return {
            ok: true,
            evento
        }
    } catch (error) {
        console.error("Error al guardar el evento en la Base de Datos")
    }

})