export default defineEventHandler(async (event) => {
    const body = await readBody(event)

    try {
        await prisma.inscrito.deleteMany({
            where: {eventoId: Number(body.id)}
        })

        await prisma.evento.delete({
            where: {
                id: Number(body.id)
            }
        })
        return {ok: true, message: 'Evento eliminado correctamente'}
    } catch (error) {
        console.error("Error al borrar evento: ", error)
        
    }
    
})