-- DropForeignKey
ALTER TABLE `inscrito` DROP FOREIGN KEY `Inscrito_eventoId_fkey`;

-- AddForeignKey
ALTER TABLE `inscrito` ADD CONSTRAINT `inscrito_eventoId_fkey` FOREIGN KEY (`eventoId`) REFERENCES `evento`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- RedefineIndex
CREATE INDEX `inscrito_eventoId_idx` ON `inscrito`(`eventoId`);
DROP INDEX `Inscrito_eventoId_idx` ON `inscrito`;
